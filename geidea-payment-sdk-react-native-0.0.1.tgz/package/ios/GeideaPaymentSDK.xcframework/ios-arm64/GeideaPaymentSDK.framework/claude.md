# GeideaPaymentSDK iOS -- Project Reference

## Project Overview

GeideaPaymentSDK is an iOS payment SDK framework distributed as an `.xcframework`. It provides card payments, Apple Pay, Google Pay, Buy Now Pay Later (BNPL) installment plans (Valu, Souhoola), and Mobile Wallet (Meeza) for merchant apps.

- **Language**: Swift 6.0
- **Minimum iOS**: 15.0 (UIKit path), 16.0 (SwiftUI path)
- **Device**: iPhone only
- **Distribution**: Binary `.xcframework` via `build_xcframework.sh`
- **No SPM/ CocoaPods/Carthage**: Pure Xcode project with one target
- **Vendored frameworks**: `CardScan.xcframework` (pre-compiled card scanning)
- **Localization**: English + Arabic (`.xcstrings` catalog)

---

## Directory Structure

```
gdpaymentsdk_ios/
  GeideaPaymentSDK.xcodeproj/
  build_xcframework.sh               # Build script for .xcframework output
  GeideaPaymentSDK/Sources/
    GDPaymentSDK.swift                # SDK singleton entry point
    Configurations/                   # Public API types (6 files)
    DI/GDPaymentSDKDI.swift           # Composition root / service locator
    AppCoordinator/                   # Coordinator pattern (SwiftUI + UIKit)
    PaymentWrapperView/               # SwiftUI hosting layer
    PaymentFeature/                   # Main checkout (Data/Domain/Presentation)
    include/                          # Umbrella header + modulemap
    Resources/                        # Colors, Fonts, Images, Localization
    Modules/
      Core/                           # Shared utilities, extensions, networking
      DesignSystem/                   # Theme, colors, typography, components
      GDCoreUI/                       # Reusable UI components (text fields, bottom sheets)
      GDNetworkManager/               # Low-level HTTP networking
      SharedModels/                   # Shared data models, API definitions
      Features/
        BNPL/                         # Buy Now Pay Later (Valu, Souhoola)
        CardDetails/                  # Card entry form + validators
        Receipt/                      # Payment receipt UI
        ThreeDSecurePage/             # 3DS WebView authentication
        ApplePay/                     # Apple Pay integration
        ScanFeature/                  # Card scanning (camera + SDK)
        ShippingAddress/              # Shipping address collection
        MobileWallet/                 # Mobile wallet QR payment (Meeza, etc.)
        GooglePay/                    # Google Pay (WebView-based)
```

---

## SDK Entry Point & Public API

### GDPaymentSDK (Singleton)

File: `GeideaPaymentSDK/Sources/GDPaymentSDK.swift`

```swift
let sdk = GDPaymentSDK.sharedInstance()
```

- `start(configuration:path:delegate:)` -- SwiftUI path (iOS 16+). Returns `AnyView`. Host provides `Binding<[AnyHashable]>` for navigation.
- `start(configuration:navigationController:delegate:)` -- UIKit path. Pushes onto existing `UINavigationController` or presents modally.
- `end()` -- Dismisses SDK presentation.
- `resolve(_ route: AnyHashable) -> AnyView` -- Resolves `AppRoute` to SwiftUI view (deep-link support).

`SDKPresentationStyle`: `.push`, `.present`, `.bottomSheet` (UIKit contexts).

Jailbreak detection runs before configuration is applied.

### Public Configuration Types

All in `GeideaPaymentSDK/Sources/Configurations/`:

| Type | File | Key Properties |
|------|------|----------------|
| `GDPaymentSDKConfiguration` | `GDPaymentSDKConfiguration.swift` | `sessionId`, `language`, `environmentType`, `region`, `theme?`, `applePayConfig?`, `googlePayConfig?` |
| `GDSDKProtocol` | `GDSDKProtocol.swift` | Delegate: `onPaymentCompleted(result:)`, `onPaymentFailed(error:)`, `onPaymentCanceled()` |
| `GDPaymentResult` | `GDPaymentResult.swift` | `orderId`, `agreementId?`, `tokenId?`, `paymentMethod?` |
| `GDSDKError` | `GDSDKError.swift` | `code`, `message`, `details?` (public error struct) |
| `ApplePayConfigurations` | `ApplePayConfigurations.swift` | `merchantId: String` |
| `GooglePayConfigurations` | `GooglePayConfigurations.swift` | `merchantId: String`, `gatewayMerchantId: String`, `merchantName: String` |

### Theme & Localization

| Type | File | Key Properties |
|------|------|----------------|
| `SDKTheme` | `DesignSystem/Sources/SDKTheme.swift` | `style` (light/dark), `primaryColor`, `secondaryColor`, `arFontType` (Almarai), `enFontType` (Montserrat/Satoshi), `merchantLogo`, `merchantName` |
| `AppLanguage` | `DesignSystem/Sources/ThemeManager.swift` | `.english` ("en"), `.arabic` ("ar") |
| `Region` | `SharedModels/Sources/SDKEnvironment.swift` | `.egy`, `.ksa`, `.uae` |
| `EnvironmentType` | Same file | `.sandbox`, `.production` |

---

## Architecture Patterns

### 1. Coordinator Pattern (Navigation)

Files: `AppCoordinator/`, `Modules/Core/Sources/Coordinator/`

Dual implementation for SwiftUI and UIKit:

| Class | Purpose |
|-------|---------|
| `GeideaSDKCoordinator` | Base class. Holds `DIContainer`, manages `presentationStack`. Routes `AppRoute` values to views. Calls `endModule()` to fire SDK delegate callbacks. |
| `SwiftUIAppCoordinator` | SwiftUI subclass. Uses `Binding<[AnyHashable]>` for programmatic `NavigationStack`. |
| `UIKitAppCoordinater` | UIKit subclass. Wraps views in `LockedOrientationViewController`. Uses `UINavigationController` push/pop. |

Protocols: `Coordinator` (base), `MainCoordinator` (with `SwiftUIMainCoordinator` and `UIKitMainCoordinator` sub-protocols), `ChildCoordinator` (delegates to main coordinator, used by feature coordinators).

**AppRoute** enum (navigation graph):
```
.paymentlandingPage
.threeDSecurePage(html, result)
.scanCardPage(result, timeout)
.receiptPage(flow, mode, orderDetails, ...)
.bnplPage(viewModel)
.bnplCardPaymentPage(amount, bnplViewModel)
.mobileWalletPage(viewModel: MobileWalletViewModelBox)
.googlePayPage(html: String, result: GooglePayResultWrapper)
```

Presentation system: `PresentationStyle` supports `.sheet`, `.popover`, `.fullScreenCover` via `CoordinatorPresentationModifier`.

### 2. Dependency Injection

File: `GeideaPaymentSDK/Sources/DI/GDPaymentSDKDI.swift`

`GDPaymentSDKDI` is the composition root. It holds `GDPaymentSDKConfiguration` and `SDKNetworkManager`. Factory methods:

- `createPaymentView(mainCoordinator:)` -- PaymentView + PaymentViewModelImp
- `createBNPLViewModel(...)` -- delegates to `BNPLDIContainer`
- `createBNPLCardPaymentView(...)` -- PaymentView for BNPL down payment
- `createMobileWalletView(viewModel: MobileWalletViewModel)` -- `MobileWalletQRView`
- `createCardScanDIContainer(...)` -- `DICardScan`
- `createCardDetailsDIContainer(...)` -- `CardDetailsDIContainer`
- `createDevicePaymentViewModel(...)` -- `DevicePaymentMethodsViewModelImpl` (now takes `coordinator` + creates `PayGooglePayUseCase`)
- `creatShippingDetailsViewModel(...)` -- with countries use case
- `makeUIKitCoordinator(navController:)` / `makeSwiftUICoordinator(path:)`
- `makeSwiftUIEntryView(...)` / `makeUIKitEntryView()`

Each feature has its own DI container: `BNPLDIContainer`, `CardDetailsDIContainer`, `ThreeDSecurePageDIContainer`, `GooglePayDIContainer`, `ReceiptDIContainer`, `DICardScan`.

### 3. MVVM + Clean Architecture

Every feature uses View + ViewModel pairs with `@Published` properties, `ObservableObject`, and Combine. PaymentFeature and BNPL use Data/Domain/Presentation layers with protocol-based use cases, DTOs, and domain entity mapping.

### 4. Combine (Reactive)

Extensively used for: 3DS callbacks (`PassthroughSubject`), card scan results, device payment results, BNPL flow actions, text field validation with debounce.

### 5. Swift Generics

`CustomTextField<Validator, ErrorType, Formatter, LeadingView, TrailingView>` is the core form input building block. `PaymentView<ViewModel: PaymentViewModel>` uses associated types.

### 6. Singletons

`GDPaymentSDK`, `GDNetworkManagerImp`, `ThemeManager`, `LocalizationManager`, `SizeHandler`.

---

## Network Layer (Three-Tier)

### Layer 1: GDNetworkManager (Low-Level HTTP)

Files: `Modules/GDNetworkManager/Sources/`

| Component | Responsibility |
|-----------|----------------|
| `GDNetworkManager` protocol | `executeAPI<T: Decodable>(_ api: API) async throws -> T` |
| `GDNetworkManagerImp` | Singleton. Thread-safe via dispatch queue. Uses `RequestBuilder`, `ResponseBuilder`, `ErrorHandler`. |
| `API` protocol | Defines `fullURL`, `endPoint`, `method`, `customHeaders`, `parameters` |
| `RequestBuilder` | Creates `URLRequest`. Handles GET query params, POST body encoding. |
| `ResponseBuilder` | Decodes JSON `Data` into `T: Decodable`. |
| `ErrorHandler` | Maps HTTP status codes / `URLError` / network errors to `NetworkError`. |
| `Reachability` | `SCNetworkReachability`-based connectivity check. |

`HTTPMethod` enum: GET, POST, DELETE, PUT.

### Layer 2: SDKNetworkManager (SDK-Specific)

File: `Modules/Core/Sources/Network/Helpers/SDKNetwrokManager.swift`

- Wraps `GDNetworkManager`. Inspects `responseCode` (success = `"000"`). Maps network errors to `GDError`.

### Layer 3: API Definitions

**Core Payment APIs** (`SharedModels/Sources/Network/APIs/SDKAPI.swift`):
- Base path: `/pgw/api/v1/SDK`
- Endpoints: `retrievePaymentConfig`, `cardAuthentication`, `cardPay`, `retrieveSupportedCountries`, `applepay`

**BNPL APIs** (`Features/BNPL/Services/BNPLAPI.swift`):
- Base path: `/bnpl/api/SDK`
- Endpoints: `inquiry`, `verifyCustomer`, `retrieveInstallmentPlans`, `reviewTransaction`, `selectInstallmentPlan`, `generateOtp`, `confirm`

### Supporting Types

- `GDNetworkConfigurationsImp` -- baseURL, language, timeout (60s), session
- `DefaultHeadersBuilder` -- Content-Type, OS version, device model, language, SDK version
- `GDSDKBaseResponse` -- Protocol with `responseCode`, `detailedResponseCode`, `responseMessage`, `detailedResponseMessage`
- `GDError` -- Internal error struct. Static conveniences: `.generalError`, `.unAuthorized`, `.missingInternetConnection`
- `SDKEnvironment` (13 cases: EGY/KSA/UAE x dev/test/preprod/prod) -- maps to base URLs

---

## Module Details

### Core Module

Path: `Modules/Core/Sources/`

| Subdirectory | Key Files | Purpose |
|--------------|-----------|---------|
| Constants | `AppConstants.swift` | SDK version, `PaymentOperation` (.pay, .saveCard) |
| Coordinator | `AppRoute.swift`, `MainCoordinator.swift`, etc. | Navigation architecture |
| Components | `GDButton.swift`, `LoaderView.swift`, `AmountWithCurrencyView.swift`, etc. | Reusable UI components |
| Extensions | `String+RSAEncyption.swift`, `String+Localize.swift`, `UIDevice+isJailBroken.swift`, `View+SecureScreen.swift`, `SDKEnvironment+BaseUrl.swift` | RSA encryption (PKCS#1/OAEP SHA1, 2048-bit key), localization, jailbreak detection, secure screen |
| LocalizationManager | `LocalizationManager.swift` | Singleton, switches `.lproj` bundles for en/ar |
| Modifires | `View+LoadingOverlay.swift`, `View+ErrorAlert.swift`, `View+popup.swift` | `LoadingState` enum (.idle, .blocking, .dimmed), error alerts, popup sheets |
| Utilites | `Validator.swift`, `JailBrokenHelper.swift`, `ViewControllerUtils.swift` | Top view controller discovery, SwiftUI detection |

### DesignSystem Module

Path: `Modules/DesignSystem/Sources/`

| File | Purpose |
|------|---------|
| `SDKTheme.swift` | Public theme config struct |
| `ThemeManager.swift` | Singleton `ObservableObject`. Manages theme, language, region. |
| `Colors/Color.swift` | Semantic color palette: `Accent` (13 shades), `Danger`, `Gradient`, `Neutral` (10 shades), `Success`, `Surface` (4), `Transparent`, `Warning`. Dynamic `primaryColor`/`secondaryColor` from `ThemeManager`. |
| `Typography/Style+Font.swift` | `Style.Font` with weight x size. Custom fonts: Almarai (Arabic), Satoshi (English). Auto-registers fonts. |
| `Typography/View+Typography.swift` | `.typography(_ fontStyle:)` ViewModifier |
| `Extensions/Color+Extension.swift` | `Color(hex:)` initializer |

**Resources**: `Palette.xcassets` (colors), Fonts (Almarai .otf, Satoshi .otf, Montserrat .ttf), `Media.xcassets` (card brand icons, logos, receipt icons, UI icons), `Localizable/` (en/ar `.strings`).

### GDCoreUI Module

Path: `Modules/GDCoreUI/Sources/`

| Subdirectory | Key Components |
|--------------|----------------|
| Styling | `Style.Spacing` (xxs-xxl), `Style.Size` (s1-s100), `Style.CornerRadius`, `Style.Border` |
| Components/CustomTextField | `CustomTextField<Validator, ErrorType, Formatter, LeadingView, TrailingView>` -- generic text field with floating placeholder, validation, formatting, error display, focus state |
| Components/GDBottomSheet | `GDBottomSheet<Content, Header, Footer>` -- dimmed background, auto-measuring, scroll support |
| Components/DatePicker | `DatePickerView`, `WheelMonthYearPicker` |
| Components/ButtonWithLoader | Button with integrated loading spinner |
| Components/GDWebView | WKWebView wrapper for SwiftUI |
| SizeHandler | Singleton for responsive sizing. `.w`, `.h`, `.r` extensions for width/height/ratio scaling |
| Extenstions/View | `View+HalfSheet.swift`, `View+GDBottomSheet.swift`, `View+Shimmering.swift`, `View+Scrollable.swift` |

### SharedModels Module

Path: `Modules/SharedModels/Sources/`

| Subdirectory | Key Types |
|--------------|-----------|
| `Network/` | `GDSDKBaseResponse`, `GDError`, `SDKAPI`, `DefaultHeadersBuilder`, `GDNetworkConfigurationsImp` |
| `CardPay/` | `CardPayRequest`, `CardPayResponse`, `PayPaymentMethod`, `SharedPaymentMethod` |
| `ApplePay/` | `ApplePayRequest`, `ApplePayToken`, `ApplePayPaymentData`, `ApplePayPaymentConfiguration` |
| `GooglePay/` | `GooglePayResponse` (message, detailedMessage, orderId) |
| `Receipt/` | `ReceiptFlow` (.CARD, .BNPL), `ReceiptMode` (.success/receiptSuccess/failure), `ReceiptUIModel` |
| Root | `SDKEnvironment`, `AuthenticationRequest`, `AuthenticationResponse` (with `gatewayDecision`, `htmlBodyContent`), `ThreeDSecureError`, `SharedCard`, `OrderDetailItem`, `PaymentMethodSupportedCard` |

---

## Feature Modules

### PaymentFeature (Main Checkout)

Path: `GeideaPaymentSDK/Sources/PaymentFeature/`

Clean Architecture with Data/Domain/Presentation:

**Domain**: `RetrievePaymentConfigUseCase`, `PayApplePayUseCase`, `PayGooglePayUseCase`, entities (`PaymentConfig`, `PaymentMethod`, `OrderSummary`, `OrderDetail`, `OrderItem`, `MerchantConfigurations`, `SavedCards`).

**Data**: `RetrievePaymentConfigUseCaseImpl`, `PayApplePayUseCaseImpl`, `PayGooglePayUseCaseImpl` (placeholder — will use `PerformAuthentication` + `/pay`), DTOs (`PaymentConfigDTO`, `PaymentMethodDTO`, `OrderSummaryDTO`, `PayGooglePayResponseDTO`, etc.).

**Presentation**:
- `PaymentViewModelImp` (~930 lines) -- orchestrates checkout: fetches payment config, manages card details, payment methods, BNPL providers, 3DS flow, Apple Pay, receipt navigation.
- `PaymentView` -- SwiftUI view with order summary, device payments, payment methods, card payment bottom sheet, BNPL flow sheet.
- Sub-views: `CardPaymentView`, `CardFormView`, `DevicePaymentMethodsView`, `OrderDetailsView`, `PaymentMethodsView`, BNPL-related views.

### BNPL Feature (Buy Now Pay Later)

Path: `Modules/Features/BNPL/`

The most complex feature. Full MVVM + Clean Architecture.

**Supported Providers**: Valu (`"valu"`), Souhoola (`"souhoola"`). Provider names come from `PaymentMethod.name?.lowercased()`.

**API Endpoints** (all under `/bnpl/api/SDK`):

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `inquiry/{provider}` | GET | Returns dynamic screens for the provider |
| `verifyCustomer` | POST | Verifies customer identity |
| `RetrieveInstallmentPlans` | POST | Fetches available plans for down payment |
| `reviewTransaction` | POST | Souhoola: reviews transaction before plan selection |
| `SelectInstallmentPlan` | POST | Selects a specific plan |
| `generateOtp` | POST | Sends OTP to customer |
| `confirm` | POST | Confirms transaction with OTP |

**ViewModels**:

| ViewModel | File | Role |
|-----------|------|------|
| `BNPLViewModel` | `ViewModels/BNPLViewModel.swift` | Root VM. Manages `currentScreenIndex`, drives inquiry, creates child VMs. Publishes `BNPLFlowAction`. Uses `BNPLViewModelBox` for Hashable/Sendable wrapping in `AppRoute`. |
| `VerifyCustomerViewModel` | `ViewModels/VerifyCustomerViewModel.swift` | Parses inquiry attributes into dynamic text fields. Validates and calls verify API. |
| `PlanSelectionViewModel` | `ViewModels/PlanSelectionViewModel.swift` | Dynamic text fields, fetches plans on field changes (1s debounce), handles plan selection. Supports both Valu (select plan here) and Souhoola (split flow) paths. |
| `ReviewTransactionViewModel` | `ViewModels/ReviewTransactionViewModel.swift` | Souhoola-specific. Calls reviewTransaction API, displays loan breakdown. |
| `BNPLOTPViewModel` | `ViewModels/BNPLOTPViewModel.swift` | OTP entry with dynamic digit count (from inquiry regex), auto-submit, countdown timer. |

**BNPLFlowAction** enum: `.proceedToCardPayment(amount:)`, `.proceedToOTP`, `.showReceipt(ConfirmResponse)`.

**Models** (7 response types): `InstallmentResponse`, `VerifyCustomerResponse`, `RetrieveInstallmentPlansResponse`, `ReviewTransactionResponse`, `SelectPlanResponse`, `GenerateOtpResponse`, `ConfirmResponse`.

**Domain Use Cases** (7, all protocol + Impl pattern): `BNPLInquiryUseCase`, `BNPLVerifyCustomerUseCase`, `BNPLRetrieveInstallmentPlansUseCase`, `BNPLReviewTransactionUseCase`, `BNPLSelectInstallmentPlanUseCase`, `BNPLGenerateOtpUseCase`, `BNPLConfirmUseCase`.

**DI**: `BNPLDIContainer` -- single factory `makeBNPLViewModel(sessionId:orderId:amount:type:)` creating all 7 use cases.

**Views**: `BNPLContainerView` (main container), `VerifyCustomerView`, `RetrieveAndSelectView` (with `InstallmentPlanSelectorView`, `PaymentMethodRowView`, `SummaryCardView`), `ReviewTransactionView`, `BNPLVerificationOTPView`.

**PaymentFeature BNPL Views** (`PaymentFeature/Presentation/SubViews/BNPL/`): `BNPLProviderSelectionView`, `BNPLProviderHeaderView`, `BNPLProviderRowView`, `BNPLProviderFooterView`, `BNPLProviderSearchBar`.

**Server-Driven UI**: The inquiry response returns `InstallmentScreen` objects with `pageName` ("VerifyCustomer", "RetrieveAndSelect", "ReviewTransaction", "Confirm") and `urls` with `ScreenAttribute` defining dynamic form fields (name, placeholder, regex, type, required).

**Provider Flow Branching**: Presence of `selectInstallmentPlan` URL on the RetrieveAndSelect screen determines Valu path (select plan here) vs Souhoola path (review transaction first, then select plan).

**Parent-Child Communication**: Child ViewModels hold `unowned` references to `BNPLViewModel`. They read from and write to `parent.collectedData` to pass data between screens.

#### BNPL Complete User Flow

```
PaymentView (checkout)
  |-- [bottom sheet] BNPLProviderSelectionView (select provider)
  |-- [bottom sheet] BNPLFlowSheetContent (VerifyCustomer, initial)
  |       |
  |       v  (index > 0 triggers full-screen push)
  |-- [full screen push] BNPLContainerView
  |       |-- VerifyCustomerView
  |       |-- RetrieveAndSelectView
  |       |       |-- SummaryCardView
  |       |       |-- InstallmentPlanSelectorView (with CustomStepSlider)
  |       |       |-- PaymentMethodRowView (Online/CashOnDelivery)
  |       |
  |       |-- [sheet] ReviewTransactionView (Souhoola only)
  |       |-- [sheet] BNPLVerificationOTPView (OTP)
  |
  |-- [push] PaymentView (bnplCardPaymentPage, card-only)
  |-- [push] ReceiptView (BNPL receipt)
```

**Valu Flow**: Verify -> RetrieveAndSelect (with select plan) -> Card Payment or OTP -> Receipt

**Souhoola Flow**: Verify -> RetrieveAndSelect (no select plan URL) -> ReviewTransaction -> select plan -> Card Payment or OTP -> Receipt

### CardDetails Feature

Path: `Modules/Features/CardDetails/Sources/`

- `CardDetailsDIContainer` creates `CardDetailsViewModelImp` with `CardAuthenticationUseCaseImpl` and `CardPayUseCase`.
- Individual field ViewModels with validators: `CardNumberValidator` (Luhn + supported card regex), `CardNameValidator`, `CVVValidator`, `ExpiryDateValidator`.
- Formatters: `CardNumberFormatter`, `CVVFormatter`.
- `SavedCardsView` with `CardItemView` for card-on-file.
- Unit tests in `Tests/` (currently commented out/boilerplate).

### Receipt Feature

Path: `Modules/Features/Receipt/Sources/`

- `ReceiptDIContainer` + `ReceiptCoordinator` (ChildCoordinator) + `ReceiptViewModelImpl`.
- Supports `ReceiptFlow.CARD` and `ReceiptFlow.BNPL`.
- Sub-views: `ReceiptStatusView`, `ReceiptOrderDetailsSection`, `ReceiptPaymentDetailsSection`, `ReceiptPaymentMethodSection`, `ReceiptSummarySection`, `ReceiptButton`, `ReceiptShareSheet`, `ReceiptZigZagShape`.
- Fullscreen presentation style.

### ThreeDSecurePage Feature

Path: `Modules/Features/ThreeDSecurePage/Sources/`

- `ThreeDSecurePageDIContainer` + `ThreeDSecurePageCoordinator` (ChildCoordinator).
- `ThreeDSecurePageViewModel`: WKWebView, intercepts return URL, parses order ID / error codes, sends results via `ThreeDSecureObserver` PassthroughSubject.
- `ThreeDSecureWebConfigBuilder`: WKWebView configuration with user scripts.

### ApplePay Feature

Path: `Modules/Features/ApplePay/Sources/`

- `ApplePayProcessor`: Manages `PKPaymentAuthorizationViewController` lifecycle.
- `ApplePayPaymentRequestBuilder`: Builds `PKPaymentRequest` from items and config.
- `ApplePayPaymentManager`: Orchestrates the flow.
- Models: `ApplePayPaymentItem`, `ApplePayPaymentResult` (success/failure/cancelled).

### GooglePay Feature

Path: `Modules/Features/GooglePay/Sources/`

Uses WKWebView to load Google Pay JavaScript API (no native iOS API exists). Follows the same pattern as `ThreeDSecurePage`.

**Structure**:
```
GooglePay/Sources/
  Components/GooglePayButton.swift          # Custom SwiftUI button (black pill, Google "G" + "Pay")
  Models/GooglePayPaymentResult.swift       # GooglePayResult, GooglePayError, GooglePayObserver, GooglePayResultWrapper
  Constants/GooglePayWebViewConstants.swift  # Callback URL, success code, URL query keys
  Helpers/GooglePayHTMLBuilder.swift         # Generates HTML loading Google Pay JS API
  Helpers/GooglePayWebConfigBuilder.swift    # WKWebView config (viewport + print override scripts)
  ViewModel/GooglePayWebViewModel.swift      # WebView VM, implements GDWebViewCallBackProtocol
  View/GooglePayWebView.swift               # GDWebView + loading overlay + back button
  Coordinator/GooglePayCoordinator.swift     # ChildCoordinator (same as ThreeDSecurePageCoordinator)
  DIContainer/GooglePayDIContainer.swift     # Creates VM + View
```

**`GooglePayButton`**: Black pill-shaped button with Google "G" paymark image (`"googlePay"` asset) + "Pay" text. Same height as Apple Pay button.

**`GooglePayHTMLBuilder`**: Generates full HTML page that:
- Loads Google Pay JS API from `https://pay.google.com/gp/p/js/pay.js`
- Configures `PaymentsClient` (TEST environment), `IsReadyToPayRequest`, `PaymentDataRequest`
- Supports `PAN_ONLY` + `CRYPTOGRAM_3DS` auth methods, VISA/MASTERCARD/AMEX networks
- On success: redirects to `https://geideapaymentsdk.com/googlepay?code=000&token=<token>`
- On cancel: redirects with `?code=CANCELED`
- On error: redirects with `?code=ERROR&msg=<message>`
- Has error display div for initialization failures

**`GooglePayWebViewConstants`**: Callback URL `geideapaymentsdk.com/googlepay`, success code `"000"`, query param keys (`code`, `msg`, `token`).

**`GooglePayWebViewModel`**: Implements `GDWebViewCallBackProtocol`. Intercepts callback URLs by matching `geideapaymentsdk.com/googlepay`, parses query params, sends results via `GooglePayObserver` (PassthroughSubject). Handles success (token), cancel, and error cases. Calls `coordinator.pop()` after result.

**`GooglePayResultWrapper`**: Hashable wrapper around `GooglePayObserver` (same pattern as `ThreeDSecureResult`).

**PaymentFeature integration**:
- `DevicePaymentMethod` enum extended with `case googlepay = "googlepay"`
- `DevicePaymentMethodsView` renders `GooglePayButton` for `.googlepay` case
- `DevicePaymentMethodsViewModelImpl.handleGooglePayTap()`: generates HTML using `GooglePayConfigurations` values, creates observer, subscribes to token result, pushes `.googlePayPage` route
- Token result flows through `resultSubject` → `PaymentViewModelImp.observeDevicePayment()` (same path as Apple Pay)
- Google Pay hidden when `googlePayConfig` is nil (same pattern as Apple Pay hidden when `applePayConfig` is nil)

**Public API**: `GooglePayConfigurations` (in `Configurations/`) — merchant app passes `merchantId`, `gatewayMerchantId`, `merchantName` from session response. Added to `GDPaymentSDKConfiguration.init(googlePayConfig:)`.

**Backend contract**: Google Pay uses the same `PerformAuthentication` + `/pay` endpoints as card payment (no dedicated endpoint). `PayGooglePayUseCaseImpl` is a placeholder throwing `not_implemented` until backend contract is finalized.

**Mock data** (`#if DEBUG`): `MockedPaymentViewModel` passes test `GooglePayConfigurations` with session response values for testing.

### ScanFeature Feature

Path: `Modules/Features/ScanFeature/Sources/`

- Two scan modes: `.cardSDk` (Stripe-like SDK) and `.card` (custom camera).
- Camera pipeline: `CameraService`, `CameraSessionBuilder`, `CameraInputConfigurator`, `CameraOutputConfigurator`, `PreviewView`, `TorchController`.
- Card processing: `CardTextRecognizer`, `ImageProcessor`, `CardValidator`, `CardScan`.
- `DICardScan` + `CardScanCoordinator`.

### ShippingAddress Feature

Path: `Modules/Features/ShippingAddress/Sources/`

- Domain entities: `ShippingDetails`, `Address`, `PersonalInfo`, `Country`.
- Use case: `RetrieveSupportedCountriesUseCase`.
- ViewModels: `ShippingDetailsViewModelImpl`, `PersonalInfoViewModel`, `AddressViewModel`, `BillingAddressViewModelImp`, `ShippingAddressViewModelImp`.
- Views: `ShippingDetailAddressView`, `AddressView`, `PersonalInfoView`, `CountryPickerMenu`.

### MobileWallet Feature

Path: `Modules/Features/MobileWallet/`

Supports mobile-wallet QR payment flows (Meeza and future providers). APIs not yet integrated — scaffolded for future connection.

**Structure**:
```
MobileWallet/
  Models/MobileWalletModels.swift       # MobileWalletInitiateResponse (placeholder Decodable)
  ViewModels/MobileWalletViewModel.swift # @MainActor ObservableObject + MobileWalletViewModelBox
  Views/MobileWalletQRView.swift        # Full-screen QR payment screen
```

**`MobileWalletViewModel`** (`@MainActor final class`, `ObservableObject`, `Identifiable`):
- Properties: `id: UUID`, `providerName: String`, `providerIconURL: URL?`, `amount: Double`, `currency: String`, `phoneNumber: String`
- Published: `qrCodeString: String?` (nil until API populates it), `timeRemaining: Int` (starts at 30)
- `startTimer()` — fires Combine `Timer.publish` countdown from 30s. On expiry, pops QR view and pushes failed receipt.
- `cancel()` — cancels timer, calls `coordinator.pop()`
- `showFailedReceipt()` — private. Pops QR view then pushes `ReceiptView` with failure mode. Stack becomes `PaymentView → ReceiptView` so "Back to checkout" returns correctly.
- Holds `coordinator: any MainCoordinator` reference (injected via init)

**`MobileWalletViewModelBox`** — `@unchecked Sendable, Hashable` wrapper (same pattern as `BNPLViewModelBox`). Equality/hashing uses `viewModel.id`.

**`MobileWalletQRView`** (full-screen, pushed via `AppRoute`):
- Header: provider logo (AsyncImage, height 100, centered)
- Payment row: "Mobile wallet payment" label | `AmountWithCurrencyView` (right-aligned)
- Divider
- "We are waiting for you" (bold), description paragraph, countdown "MM:SS" (always visible, no refresh button)
- "Didn't receive a notification?" (bold), QR code (150×150, CoreImage `CIQRCodeGenerator`, placeholder when nil), scan description
- Cancel button (full-width `GDButton` secondary, pinned at bottom via `ZStack`)
- On timer expiry: ViewModel navigates to failed receipt automatically

**Flow** (PaymentFeature integration):
1. User selects provider (e.g., Meeza) on payment landing → `selectedMobileWalletProvider` set, `selectedBNPLProvider` cleared (mutual exclusion)
2. "Continue with Meeza" button visible → tapping calls `startMobileWalletFlow(for:)` → shows `.mobileWalletFlow` bottom sheet
3. `MobileWalletPhoneView` bottom sheet — phone number entry matching VerifyCustomerView style, Continue button
4. Tapping Continue → `proceedToMobileWalletQR(phoneNumber:)` — dismisses sheet, creates `MobileWalletViewModel`, pushes `.mobileWalletPage`
5. Full-screen `MobileWalletQRView` shown with 30s countdown timer
6. Timer expiry → QR view popped, failed `ReceiptView` pushed → "Back to checkout" returns to `PaymentView`

**Payment method mutual exclusion** (`PaymentView.swift`):
- Selecting a BNPL provider clears `selectedMobileWalletProvider` (and vice versa)
- Only one "Continue with [provider]" button shows at the bottom at a time
- Most recently selected payment method is treated as the default

**`PaymentViewModel` protocol additions**:
- `func startMobileWalletFlow(for provider: PaymentMethod)` — shows phone entry bottom sheet
- `func proceedToMobileWalletQR(phoneNumber: String)` — dismisses sheet, pushes QR screen

**Localization keys added** (EN/AR in `Localizable.xcstrings`):
- `mobile_wallet_payment` — "Mobile wallet payment" / "دفع محفظة الجوال"
- `mobile_wallet_waiting_title` — "We are waiting for you" / "نحن في انتظارك"
- `mobile_wallet_waiting_desc` — Full instruction paragraph / Arabic equivalent
- `mobile_wallet_no_notification` — "Didn't receive a notification?" / "لم تتلق إشعارًا؟"
- `mobile_wallet_scan_desc` — "Scan the QR code using your wallet application to initiate the payment." / Arabic
- `enter_phone_number` — "Enter your phone number" / "أدخل رقم هاتفك"
- `select_mobile_wallet` — "Select mobile wallet" / "اختر محفظة الجوال"

**`MobileWalletPhoneView`** (`PaymentFeature/Presentation/SubViews/MobileWallet/`):
- Bottom sheet matching BNPL "Verify Customer" style — same HStack header (bold title + X dismiss), `VStack(spacing: 10)`, `.padding(.horizontal)`
- Uses `CustomTextFieldViewModel<PhoneValidator, PhoneValidationError, DefaultFormatter>` with full styling matching VerifyCustomerView fields: `placeholderFont: Font(Style.Font.medium.five.font)`, `placeholderColor: .Neutral.neutral4`, `textFont: Font(Style.Font.bold.five.font)`, `textColor: .Neutral.neutral1`, `borderColor: .clear`, `focusedBorderColor: Color.primaryColor`, `backgroundColor: Color.Surface.surface2`, `height: Style.Size.s66`
- Continue button state (`.disabled`/`.default`) driven by `phoneVM.text` emptiness

---

## Build System

Script: `build_xcframework.sh`

```bash
# Steps:
1. Clean previous builds under ./build/
2. xcodebuild archive -sdk iphoneos (arm64) -configuration Release
3. xcodebuild archive -sdk iphonesimulator (arm64 + x86_64)
4. xcodebuild -create-xcframework -> ./build/GeideaPaymentSDK.xcframework
```

Key flags: `BUILD_LIBRARY_FOR_DISTRIBUTION=YES`, `SKIP_INSTALL=NO`, `ENABLE_MODULE_VERIFIER=YES`.

---

## Git Branching

- `dev` -- main development branch
- `release_1.0.0` / `pilot_release_1.0.0` -- release branches
- `feature/*` -- feature branches (e.g., `feature/BNPL/error_display_fix`, `feature/new_checkout_sheet`)
- `test` -- testing branch

---

## Key Patterns & Conventions

1. **Protocol + Impl pattern**: Every use case has a protocol and an `Impl` class. DI injects the impl via the protocol.
2. **`@MainActor`**: SDK entry point and ViewModels are `@MainActor`.
3. **`@unchecked Sendable`**: Used for `GDPaymentSDK` and `BNPLViewModelBox` where `@MainActor` guarantees thread safety but the compiler can't verify it.
4. **Error handling**: Errors cast to `GDError` to extract `detailedMessage`. `GDError.errorDescription` returns `detailedMessage` (falling back to `message`).
5. **Loading states**: `LoadingState` enum (.idle, .blocking, .dimmed) with `loadingOverlay` ViewModifier.
6. **Security**: RSA encryption for card data (PKCS#1/OAEP SHA1, 2048-bit hardcoded public key), secure screen overlay (blocks recording), jailbreak detection.
7. **Localization**: Full AR/EN support via `.lproj` bundles, layout direction switching, font family switching (Almarai for Arabic, Satoshi for English).
8. **Dynamic form fields**: BNPL uses server-driven `ScreenAttribute` to build form fields with regex validation.
9. **Custom decoding**: BNPL response models have custom `Decodable` initializers to handle backend type inconsistencies (`Int` vs `String` for `souhoolaTransactionId`).

---

## Known Issues & Technical Debt

- Unit tests in `CardDetails/Tests/` are entirely commented out (boilerplate only, no test target in project).
- `SelectInstallmentPlanBody` has old nested structure commented out alongside the new flat structure -- pending backend confirmation.
- `SDKNetwrokManager.swift` filename has a typo (missing 'k' in Network).
- BNPL OTP auto-reset uses `Task.sleep(nanoseconds:)` for 1.5s delay on failure.

---

## Souhoola BNPL Integration Status

### Completed Work

1. **Split Flow Architecture**: Verify -> RetrieveAndSelect -> ReviewTransaction -> Select -> OTP/Receipt. Navigation uses inline swaps for base screens and `NavigationLink` pushes for terminal screens.
2. **Server-Driven Logic**: Branching relies on inquiry response attributes/URLs rather than hardcoded provider names.
3. **ReviewTransaction Screen**: New `loadReviewTransaction` API call on appear. Displays merchant name, loan amount, installment values/dates.
4. **Flat SelectInstallmentPlan Payload**: All parameters at top level (not nested in `bnplDetails`).
5. **Resilient JSON Decoding**: Custom `Decodable` for type inconsistencies.
6. **Dynamic SummaryCardView**: Rows hidden when zero values.
7. **Receipt-style ReviewTransactionView**: Flat layout, loading overlays, conditional rendering.

### Bug Fixes Applied

- Transaction ID propagation through all steps via `collectedData`.
- Navigation index sync for pushed screens.
- White screen on back navigation fix (inline screen based on child ViewModel existence).
- Receipt X button reports correct status (success/failure/cancel).
- BNPL API error messages: parse response body before checking HTTP status code.
- `GDError.errorDescription` returns `detailedMessage` for specific BNPL error messages.
- Light appearance enforcement on payment/BNPL surfaces.
- Fullscreen receipt presentation.
- OTP screen container sizing/background for dark strip prevention.

### Next Steps

- End-to-end testing of full Souhoola flow.
- Regression testing of Valu flow after `SelectInstallmentPlan` changes.
- Confirm flat payload accepted by backend, remove commented nested structure.

---

## Latest Updates (April-May 2026)

- Theme & appearance stabilization: consistent light appearance, explicit surface backgrounds.
- Receipt fullscreen presentation via `ReceiptDIContainer`.
- Error display fix branch: `feature/BNPL/error_display_fix`.
- Card field focus borders, buttons, BNPL controls, OTP fields now use `Color.primaryColor` (removed hardcoded `Color.Accent.accent13`).
- Removed `@MainActor` from `Color.primaryColor`/`secondaryColor` and `ThemeManager.default` to fix compiler isolation errors.
- Clock icon changed to system name image.
- Date format updates.
- Close function logic fixes.
- Modified error handling to be presented with details.
- **Mobile Wallet feature scaffolded** (May 2026): `MobileWalletViewModel`, `MobileWalletQRView`, `MobileWalletViewModelBox`, `MobileWalletPhoneView`. AppRoute, GeideaSDKCoordinator, GDPaymentSDKDI, PaymentViewModel all wired up. API integration TODO (placeholder `MobileWalletInitiateResponse` model in place).
- **Mobile Wallet UI refinements** (May 2026):
  - Payment method mutual exclusion: selecting BNPL clears mobile wallet selection and vice versa — only one "Continue with..." button at bottom.
  - `MobileWalletPhoneView` restyled to match BNPL `VerifyCustomerView` (same header, text field config, spacing, padding).
  - Timer expiry navigates to failed `ReceiptView` (no refresh button). Pops QR view first so "Back to checkout" returns to `PaymentView`.
- **Google Pay feature added** (May 2026, branch: `feature/mobile_wallet/mobile_wallet_ui_impl`):
  - WebView-based flow (WKWebView loading Google Pay JS API) following `ThreeDSecurePage` pattern.
  - Full feature module: `GooglePayButton`, `GooglePayWebView`, `GooglePayWebViewModel`, `GooglePayCoordinator`, `GooglePayDIContainer`, `GooglePayHTMLBuilder`, `GooglePayWebConfigBuilder`, result types.
  - Added to device payment section alongside Apple Pay via `DevicePaymentMethod.googlepay` enum case.
  - `AppRoute.googlePayPage(html:result:)` route added, resolved in `GeideaSDKCoordinator`.
  - `GDPaymentSDKDI.createDevicePaymentViewModel` now takes `coordinator` param and creates `PayGooglePayUseCase`.
  - `PayGooglePayUseCaseImpl` is a placeholder — will use `PerformAuthentication` + `/pay` when backend contract is finalized.
  - `GooglePayConfigurations` public API added (`merchantId`, `gatewayMerchantId`, `merchantName`) — merchant app passes values from session response. Wired through DI to `DevicePaymentMethodsViewModelImpl`.
  - Google Pay hidden when config is nil, same as Apple Pay pattern.
  - `GooglePayHTMLBuilder` now uses real config values instead of "TODO" placeholders.
  - Mock Google Pay entry injected via `#if DEBUG` with test config for testing.
  - Shared models: `GooglePayResponse`, `PayGooglePayResponseDTO`.

---

## Important Patterns for New Features

### Adding a new full-screen feature (reference: MobileWallet)

1. **Create folder** under `Modules/Features/<FeatureName>/` with `Models/`, `ViewModels/`, `Views/` subdirs via `XcodeMakeDir`.
2. **ViewModel**: `@MainActor final class <Feature>ViewModel: ObservableObject, Identifiable`. Give it `let id = UUID()`. Pass `coordinator: any MainCoordinator` in the init for `pop()` / `endModule()`.
3. **ViewModelBox**: `final class <Feature>ViewModelBox: @unchecked Sendable, Hashable` — wraps ViewModel, equates on `viewModel.id`.
4. **AppRoute**: Add `case <feature>Page(viewModel: <Feature>ViewModelBox)` and corresponding `screenId`.
5. **GeideaSDKCoordinator**: Add `case let .<feature>Page(box): return DIContainer.create<Feature>View(viewModel: box.viewModel)`.
6. **GDPaymentSDKDI**: Add `func create<Feature>View(viewModel: <Feature>ViewModel) -> AnyView`.
7. **Navigation**: Push from parent ViewModel via `coordinator.push(.<feature>Page(viewModel: <Feature>ViewModelBox(vm)))`.

### Adding a WebView-based feature (reference: GooglePay / ThreeDSecurePage)

1. **HTML Builder**: Struct with parameters, `build() -> String` generates full HTML page.
2. **Web Config Builder**: Implements `GDWebViewBuilderProtocol` — viewport script + print override.
3. **Result types**: `Result` enum, `Error` struct, `Observer` typealias (`PassthroughSubject`), `ResultWrapper` (Hashable).
4. **Constants**: Callback URL string, success code, URL query parameter keys.
5. **WebView ViewModel**: `@MainActor ObservableObject`, implements `GDWebViewCallBackProtocol`. Intercepts callback URL, parses params, sends via observer.
6. **WebView View**: Wraps `GDWebView` with loading overlay and back button.
7. **Coordinator**: `ChildCoordinator` implementation (same as `ThreeDSecurePageCoordinator`).
8. **DI Container**: Creates VM + View, returns coordinator.
9. **AppRoute**: `case <feature>Page(html: String, result: <Feature>ResultWrapper)` with screenId.
10. **Parent pushes route**: Generate HTML, create observer, subscribe to results, push `.googlePayPage(html:result:)`.

### Text in SwiftUI (Swift 6 note)

Always use `Text(verbatim: .localized("key", bundle: .frameworkBundle))` when the localized value is a plain `String`. `Text(.localized(...))` is ambiguous in Swift 6 and causes "Missing argument label 'verbatim:'" compile errors. The only exception is `GDButtonViewModel(title:)` and similar String parameters that accept the value directly.

### Color conventions

- Primary text: `Color.Neutral.neutral1` / `.foregroundStyle(...)`
- Secondary/muted text: `Color.Neutral.neutral2`
- Surface backgrounds: `Color.Surface.surface1` (page), `Color.Surface.surface2` (cards/fields)
- Brand accent: `Color.primaryColor`
- **Do not use** `Color.Text.*` — those namespaces do not exist in this SDK.
