import Foundation
import React
import GeideaPaymentSDK
import UIKit

@objc(GeideaBridge)
class GeideaBridge: NSObject {

  @objc static func requiresMainQueueSetup() -> Bool { true }

  private var currentFlow: RNGeideaPaymentFlow?

  /// JS -> Native:
  /// GeideaBridge.startWithConfig({
  ///   sessionId: string,
  ///   language?: 'en'|'ar',
  ///   region?: 'egypt'|'ksa'|'uae'
  /// })
  @objc(startWithConfig:resolver:rejecter:)
  @MainActor
  func startWithConfig(_ params: NSDictionary,
                       resolver resolve: @escaping RCTPromiseResolveBlock,
                       rejecter reject: @escaping RCTPromiseRejectBlock) {

    guard let sessionId = params["sessionId"] as? String, !sessionId.isEmpty else {
      return reject("E_ARGS", "sessionId is required", nil)
    }

    let lang   = mapLanguage(params["language"] as? String)
    let region = mapRegion(params["region"] as? String)
    let merchantId = params["merchantId"] as? String
    let merchantName = params["merchantName"] as? String
    var theme: SDKTheme?
    if let primaryColor = params["primaryColor"] as? String,
       let secondaryColor = params["secondaryColor"] as? String {
      theme = SDKTheme(
        primaryColor: primaryColor,
        secondaryColor: secondaryColor
      )
    }

    let cfg = GeideaPaymentSDK.GDPaymentSDKConfiguration(
      sessionId: sessionId,
      applePayConfig: ApplePayConfigurations(merchantId: merchantId ?? "", merchantName: merchantName ?? "Geidea"),
      language: lang,
      region: region,
      theme: theme
    )

    Task { @MainActor in
      guard self.currentFlow == nil else {
        return reject("E_IN_PROGRESS", "Payment already in progress", nil)
      }

      guard let presenter = topPresenterViewController() else {
        return reject("E_NO_VC", "Could not find root view controller", nil)
      }

      let placeholderViewController = UIViewController()
      placeholderViewController.view.backgroundColor = .systemBackground
      placeholderViewController.view.semanticContentAttribute =
        lang == .arabic ? .forceRightToLeft : .forceLeftToRight

      let navigationController = UINavigationController(rootViewController: placeholderViewController)
      navigationController.view.semanticContentAttribute =
        lang == .arabic ? .forceRightToLeft : .forceLeftToRight
      navigationController.navigationBar.semanticContentAttribute =
        lang == .arabic ? .forceRightToLeft : .forceLeftToRight

      let containerViewController = GeideaPaymentContainerViewController(
        navigationController: navigationController
      )
      containerViewController.modalPresentationStyle = .fullScreen
      containerViewController.view.semanticContentAttribute =
        lang == .arabic ? .forceRightToLeft : .forceLeftToRight

      let flow = RNGeideaPaymentFlow(
        containerViewController: containerViewController,
        navigationController: navigationController
      )

      let delegate = RNGeideaDelegate(
        onCompleted: { [weak self, weak flow] result in
          Task { @MainActor in
            guard let self = self, let flow = flow else { return }
            self.resolveFlow(
              flow,
              response: [
                "status": "completed",
                "result": result
              ],
              resolve: resolve
            )
          }
        },
        onCanceled: { [weak self, weak flow] in
          Task { @MainActor in
            guard let self = self, let flow = flow else { return }
            self.resolveFlow(
              flow,
              response: [
                "status": "canceled"
              ],
              resolve: resolve
            )
          }
        },
        onFailed: { [weak self, weak flow] code, message, error in
          Task { @MainActor in
            guard let self = self, let flow = flow else { return }
            self.rejectFlow(
              flow,
              code: code,
              message: message,
              error: error,
              reject: reject
            )
          }
        }
      )

      flow.delegate = delegate
      self.currentFlow = flow
      self.logPresentationContext(
        presenter: presenter,
        navigationController: navigationController
      )

      let instance = GeideaPaymentSDK.GDPaymentSDK.sharedInstance()
      presenter.present(containerViewController, animated: true) {
        do {
          try instance.start(configuration: cfg, navigationController: navigationController, delegate: delegate)
        } catch {
          self.rejectFlow(
            flow,
            code: "E_SDK_START",
            message: "Failed to start SDK: \(error.localizedDescription)",
            error: error as NSError,
            animated: false,
            reject: reject
          )
        }
      }
    }
  }

  // mappers

  private func mapLanguage(_ raw: String?) -> GeideaPaymentSDK.AppLanguage {
    if let key = raw?.lowercased(), let val = GeideaPaymentSDK.AppLanguage(rawValue: key) {
      return val
    }
    switch (raw ?? "").lowercased() {
      case "ar", "arabic", "ar-eg", "ar-sa": return .arabic
      default: return .english
    }
  }

  private func mapRegion(_ raw: String?) -> GeideaPaymentSDK.Region {
    if let s = raw?.lowercased(), let v = GeideaPaymentSDK.Region(rawValue: s) {
      return v
    }
    switch (raw ?? "").lowercased() {
      case "sa", "ksa": return .ksa
      case "ae", "uae": return .uae
      case "eg", "egypt": return .egy
      default: return .egy
    }
  }

  @MainActor
  private func topPresenterViewController() -> UIViewController? {
    let activeScene = UIApplication.shared.connectedScenes
      .compactMap { $0 as? UIWindowScene }
      .first { $0.activationState == .foregroundActive }

    let fallbackScene = UIApplication.shared.connectedScenes
      .compactMap { $0 as? UIWindowScene }
      .first

    let scene = activeScene ?? fallbackScene

    let rootViewController = scene?.windows
      .first(where: \.isKeyWindow)?
      .rootViewController ?? scene?.windows.first?.rootViewController

    var presenter = rootViewController
    while let presentedViewController = presenter?.presentedViewController {
      presenter = presentedViewController
    }

    return presenter
  }

  @MainActor
  private func resolveFlow(_ flow: RNGeideaPaymentFlow,
                           response: [String: Any],
                           resolve: @escaping RCTPromiseResolveBlock) {
    finishFlow(flow) {
      resolve(response)
    }
  }

  @MainActor
  private func rejectFlow(_ flow: RNGeideaPaymentFlow,
                          code: String,
                          message: String,
                          error: NSError?,
                          animated: Bool = true,
                          reject: @escaping RCTPromiseRejectBlock) {
    finishFlow(flow, animated: animated) {
      reject(code, message, error)
    }
  }

  @MainActor
  private func finishFlow(_ flow: RNGeideaPaymentFlow,
                          animated: Bool = true,
                          completion: @escaping () -> Void) {
    guard currentFlow === flow, !flow.hasFinished else {
      return
    }

    flow.hasFinished = true

    let finish = {
      self.currentFlow = nil
      completion()
    }

    if flow.containerViewController.presentingViewController != nil {
      flow.containerViewController.dismiss(animated: animated, completion: finish)
    } else {
      finish()
    }
  }

  @MainActor
  private func logPresentationContext(presenter: UIViewController,
                                      navigationController: UINavigationController) {
    let presenterClassName = String(describing: type(of: presenter))
    let navigationClassName = String(describing: type(of: navigationController))
    NSLog(
      "[GeideaBridge] presenter=%@ presenterContainsRNS=%@ isolatedNavigationController=%@ isolatedNavigationContainsRNS=%@",
      presenterClassName,
      presenterClassName.contains("RNS") ? "true" : "false",
      navigationClassName,
      navigationClassName.contains("RNS") ? "true" : "false"
    )
  }
}

@MainActor
private final class RNGeideaPaymentFlow {
  let containerViewController: GeideaPaymentContainerViewController
  let navigationController: UINavigationController
  var delegate: RNGeideaDelegate?
  var hasFinished = false

  init(containerViewController: GeideaPaymentContainerViewController,
       navigationController: UINavigationController) {
    self.containerViewController = containerViewController
    self.navigationController = navigationController
  }
}

@MainActor
private final class GeideaPaymentContainerViewController: UIViewController {
  private let embeddedNavigationController: UINavigationController

  init(navigationController: UINavigationController) {
    self.embeddedNavigationController = navigationController
    super.init(nibName: nil, bundle: nil)
  }

  required init?(coder: NSCoder) {
    return nil
  }

  override func viewDidLoad() {
    super.viewDidLoad()
    view.backgroundColor = .systemBackground

    addChild(embeddedNavigationController)
    embeddedNavigationController.view.frame = view.bounds
    embeddedNavigationController.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
    view.addSubview(embeddedNavigationController.view)
    embeddedNavigationController.didMove(toParent: self)
  }
}

final class RNGeideaDelegate: NSObject, GeideaPaymentSDK.GDSDKProtocol {

  private let onCompleted: (_ result: [String: Any]) -> Void
  private let onCanceled: () -> Void
  private let onFailed: (_ code: String, _ message: String, _ error: NSError?) -> Void

  init(onCompleted: @escaping (_ result: [String: Any]) -> Void,
       onCanceled: @escaping () -> Void,
       onFailed: @escaping (_ code: String, _ message: String, _ error: NSError?) -> Void) {
    self.onCompleted = onCompleted
    self.onCanceled = onCanceled
    self.onFailed = onFailed
  }

  // GDSDKProtocol

  @MainActor
  func onPaymentCompleted(result: GeideaPaymentSDK.GDPaymentResult) {
    onCompleted(Self.flattenToDictionary(result))
  }

  @MainActor
  func onPaymentFailed(error: GeideaPaymentSDK.GDSDKError) {
    let dict = Self.flattenToDictionary(error)
    let code = (dict["code"] as? String) ?? "E_PAYMENT_FAILED"
    let msg  = (dict["message"] as? String)
            ?? (dict["localizedDescription"] as? String)
            ?? "Payment failed"
    onFailed(code, msg, NSError(domain: code, code: -1, userInfo: dict))
  }

  @MainActor
  func onPaymentCanceled() {
    onCanceled()
  }

  private static func flattenToDictionary(_ value: Any) -> [String: Any] {
    if let d = value as? [String: Any] { return d }
    if let e = value as? NSError {
      return ["code": e.domain, "message": e.localizedDescription]
    }
    let m = Mirror(reflecting: value)
    var out: [String: Any] = [:]
    for child in m.children {
      if let label = child.label {
        out[label] = serializeValue(child.value)
      }
    }
    return out
  }

  private static func serializeValue(_ any: Any) -> Any {
    let mirror = Mirror(reflecting: any)
    if mirror.displayStyle == .optional {
      if let child = mirror.children.first {
        return serializeValue(child.value)
      }
      return NSNull()
    }
    if mirror.displayStyle == .struct || mirror.displayStyle == .class {
      if let _ = any as? String { return any }
      if let _ = any as? NSNumber { return any }
      return flattenToDictionary(any)
    }
    return any
  }
}
